import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 2560;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // cover841 (6:483)
        padding: EdgeInsets.fromLTRB(114*fem, 0*fem, 0*fem, 0*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupsjnhkDo (ViQTej437d83MehM43SJnh)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 24*fem, 117*fem),
              width: 613*fem,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // figma11ea5 (6:914)
                    margin: EdgeInsets.fromLTRB(182.02*fem, 0*fem, 281.02*fem, 72.04*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // autogroupvxvmXNy (ViQTw3vAjZhqeZyHzgvXvM)
                          width: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // vectorEwb (6:917)
                                width: 74.98*fem,
                                height: 74.98*fem,
                                child: Image.asset(
                                  'assets/cover/images/vector-KDb.png',
                                  width: 74.98*fem,
                                  height: 74.98*fem,
                                ),
                              ),
                              Container(
                                // vectorMFX (6:918)
                                width: 74.98*fem,
                                height: 74.98*fem,
                                child: Image.asset(
                                  'assets/cover/images/vector-zcR.png',
                                  width: 74.98*fem,
                                  height: 74.98*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogrouphfmfHey (ViQU38aNT4cfxhycPQhfmf)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                          width: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // vectoroNR (6:916)
                                width: 74.98*fem,
                                height: 74.98*fem,
                                child: Image.asset(
                                  'assets/cover/images/vector-Y1P.png',
                                  width: 74.98*fem,
                                  height: 74.98*fem,
                                ),
                              ),
                              Container(
                                // vectorj1B (6:919)
                                width: 74.98*fem,
                                height: 74.98*fem,
                                child: Image.asset(
                                  'assets/cover/images/vector-Mow.png',
                                  width: 74.98*fem,
                                  height: 74.98*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // vectorsNH (6:915)
                          width: 74.98*fem,
                          height: 74.99*fem,
                          child: Image.asset(
                            'assets/cover/images/vector-4Ed.png',
                            width: 74.98*fem,
                            height: 74.99*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // loginscreenDBF (6:912)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                    constraints: BoxConstraints (
                      maxWidth: 613*fem,
                    ),
                    child: Text(
                      'Login Screen',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 172.2137451172*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.0899999619*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // designusingfigmaT5b (6:913)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 22*fem, 0*fem),
                    child: Text(
                      'Design Using Figma',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 60*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.5*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupbatxjYu (ViQUD3TXDfpuZqTwFABATX)
              width: 1809*fem,
              height: 1456*fem,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle13rtR (6:910)
                    left: 684*fem,
                    top: 74*fem,
                    child: Align(
                      child: SizedBox(
                        width: 10*fem,
                        height: 374*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(24*fem),
                            color: Color(0xfff97202),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle14kiu (6:911)
                    left: 706*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 10*fem,
                        height: 173*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(24*fem),
                            color: Color(0xfff97202),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group16UQ1 (6:909)
                    left: 0*fem,
                    top: 1125*fem,
                    child: Container(
                      width: 169*fem,
                      height: 169*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // group9NkH (6:854)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 10.64*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // ellipse1Jdw (6:829)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse2BBw (6:830)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse3geV (6:831)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse4cHF (6:832)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse5jMs (6:833)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse6rxH (6:834)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse7PhK (6:835)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse8vhF (6:836)
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // group8Rtu (6:853)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 10.64*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // ellipse9M1s (6:845)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse10Ged (6:846)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse11CHP (6:847)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse128Rw (6:848)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse1321X (6:849)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse14LH7 (6:850)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse15qDs (6:851)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse16xpH (6:852)
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // group10iHf (6:855)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 10.64*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // ellipse13qj (6:856)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse2PPo (6:857)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse3KoF (6:858)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse4fMK (6:859)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse5PYD (6:860)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse67z1 (6:861)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse7T2H (6:862)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse8PAq (6:863)
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // group11L65 (6:864)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 10.64*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // ellipse9PKF (6:865)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse10v4H (6:866)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse11F6Z (6:867)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse12mqb (6:868)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse13H3F (6:869)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse14zyF (6:870)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse15uaR (6:871)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse16qU5 (6:872)
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // group12ZQ5 (6:873)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 10.64*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // ellipse1UG9 (6:874)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse2aa5 (6:875)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse3iAV (6:876)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse4ScH (6:877)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse5ys7 (6:878)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse6W6M (6:879)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse736H (6:880)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse89v1 (6:881)
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // group14u8V (6:891)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 10.64*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // ellipse9qXw (6:892)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse10yPF (6:893)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse11goT (6:894)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse12p8y (6:895)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse13Lt1 (6:896)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse14eth (6:897)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse15nk1 (6:898)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse16WR7 (6:899)
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // group134Bj (6:882)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 10.64*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // ellipse1xH7 (6:883)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse268R (6:884)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse3q61 (6:885)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse4kTs (6:886)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse5gcR (6:887)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse62AV (6:888)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse79F7 (6:889)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse8UoB (6:890)
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // group15dg5 (6:900)
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // ellipse9nYy (6:901)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse10JGR (6:902)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse11Rbw (6:903)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse12xLy (6:904)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse135Ah (6:905)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse14ocV (6:906)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse15LsK (6:907)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.64*fem, 0*fem),
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                                Container(
                                  // ellipse16gRP (6:908)
                                  width: 11.82*fem,
                                  height: 11.82*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(5.9090909958*fem),
                                    color: Color(0xfffd7401),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle12R85 (6:828)
                    left: 1330*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 479*fem,
                        height: 1440*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xfffd7401),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // loginWvD (6:656)
                    left: 141*fem,
                    top: 215*fem,
                    child: Container(
                      width: 1569*fem,
                      height: 1010*fem,
                      decoration: BoxDecoration (
                        border: Border.all(color: Color(0xff1e2772)),
                        color: Color(0xfff1f3f6),
                        borderRadius: BorderRadius.circular(50.4863166809*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x33000000),
                            offset: Offset(0*fem, 0*fem),
                            blurRadius: 100*fem,
                          ),
                        ],
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupk5ufnMw (ViQVdfkWit869PBb2vK5uF)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.35*fem, 0.27*fem),
                            padding: EdgeInsets.fromLTRB(26.25*fem, 202.95*fem, 26.47*fem, 202.95*fem),
                            width: 482.65*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x0c000000),
                                  offset: Offset(24.2334308624*fem, 0*fem),
                                  blurRadius: 25.2431583405*fem,
                                ),
                              ],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group1RA1 (6:660)
                                  margin: EdgeInsets.fromLTRB(105.01*fem, 0*fem, 104.8*fem, 15.61*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // rectangle4iQ1 (6:661)
                                        margin: EdgeInsets.fromLTRB(0*fem, 4.19*fem, 5.59*fem, 0*fem),
                                        width: 5.59*fem,
                                        height: 55.93*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(16.7782077789*fem),
                                          color: Color(0xfffd7401),
                                        ),
                                      ),
                                      Container(
                                        // rectangle5ckH (6:664)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.59*fem, 4.19*fem),
                                        width: 5.59*fem,
                                        height: 55.93*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(16.7782077789*fem),
                                          color: Color(0xff1e2772),
                                        ),
                                      ),
                                      Container(
                                        // rectangle6Keh (6:662)
                                        margin: EdgeInsets.fromLTRB(0*fem, 4.19*fem, 5.59*fem, 0*fem),
                                        width: 5.59*fem,
                                        height: 55.93*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(16.7782077789*fem),
                                          color: Color(0xfffd7401),
                                        ),
                                      ),
                                      Container(
                                        // rectangle7ews (6:665)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.59*fem, 4.19*fem),
                                        width: 5.59*fem,
                                        height: 55.93*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(16.7782077789*fem),
                                          color: Color(0xff1e2772),
                                        ),
                                      ),
                                      Container(
                                        // rectangle8xhf (6:663)
                                        margin: EdgeInsets.fromLTRB(0*fem, 4.19*fem, 5.59*fem, 0*fem),
                                        width: 5.59*fem,
                                        height: 55.93*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(16.7782077789*fem),
                                          color: Color(0xfffd7401),
                                        ),
                                      ),
                                      Container(
                                        // networkrHF (6:666)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.43*fem),
                                        width: 164.19*fem,
                                        height: 30.33*fem,
                                        child: Image.asset(
                                          'assets/cover/images/network.png',
                                          width: 164.19*fem,
                                          height: 30.33*fem,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // loginintoyouraccountAoj (6:659)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.65*fem, 44.67*fem),
                                  child: Text(
                                    'Login into your account',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 16.155620575*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.5*ffem/fem,
                                      color: Color(0xff555555),
                                    ),
                                  ),
                                ),
                                Container(
                                  // group21ZT (6:667)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.79*fem, 28.27*fem),
                                  width: 429.13*fem,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // emailaddresswT7 (6:674)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9.33*fem),
                                        child: Text(
                                          'Email address',
                                          style: SafeGoogleFont (
                                            'Poppins',
                                            fontSize: 16.155620575*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.5*ffem/fem,
                                            color: Color(0xff555555),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // autogroupnsdkesK (ViQW2VRpUch8iWByz1NSdK)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                        padding: EdgeInsets.fromLTRB(20.19*fem, 0*fem, 0*fem, 0*fem),
                                        width: double.infinity,
                                        height: 50.49*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xfff1f3f6),
                                          borderRadius: BorderRadius.circular(8.0778102875*fem),
                                        ),
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // alexemailcomk9f (6:675)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 240.45*fem, 0.21*fem),
                                              child: Text(
                                                'alex@email.com',
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 14.1361694336*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xff555555),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // group4F6R (6:669)
                                              padding: EdgeInsets.fromLTRB(13.13*fem, 13.13*fem, 13.13*fem, 13.13*fem),
                                              height: double.infinity,
                                              decoration: BoxDecoration (
                                                color: Color(0xfffd7401),
                                                borderRadius: BorderRadius.circular(8.0778102875*fem),
                                              ),
                                              child: Center(
                                                // frameYbK (6:671)
                                                child: SizedBox(
                                                  width: 24.23*fem,
                                                  height: 24.23*fem,
                                                  child: Image.asset(
                                                    'assets/cover/images/frame-fsF.png',
                                                    width: 24.23*fem,
                                                    height: 24.23*fem,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // group3b3o (6:676)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.79*fem, 11.11*fem),
                                  width: 429.13*fem,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // password7nq (6:682)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9.33*fem),
                                        child: Text(
                                          'Password',
                                          style: SafeGoogleFont (
                                            'Poppins',
                                            fontSize: 16.155620575*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.5*ffem/fem,
                                            color: Color(0xff555555),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // autogroupugxfcjb (ViQWHZq2qg3h7EHY5VUgXf)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                                        padding: EdgeInsets.fromLTRB(20.19*fem, 0*fem, 0*fem, 0*fem),
                                        width: double.infinity,
                                        height: 50.49*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xfff1f3f6),
                                          borderRadius: BorderRadius.circular(8.0778102875*fem),
                                        ),
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // enteryourpasswordWKB (6:683)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 214.45*fem, 0.21*fem),
                                              child: Text(
                                                'Enter your password',
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 14.1361694336*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xff555555),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // autogroupm2rr22d (ViQWNEMvjNVvLMDomxm2rR)
                                              padding: EdgeInsets.fromLTRB(13.13*fem, 13.13*fem, 13.13*fem, 13.13*fem),
                                              height: double.infinity,
                                              decoration: BoxDecoration (
                                                color: Color(0xfffd7401),
                                                borderRadius: BorderRadius.circular(8.0778102875*fem),
                                              ),
                                              child: Center(
                                                // frame9N9 (6:679)
                                                child: SizedBox(
                                                  width: 24.23*fem,
                                                  height: 24.23*fem,
                                                  child: Image.asset(
                                                    'assets/cover/images/frame.png',
                                                    width: 24.23*fem,
                                                    height: 24.23*fem,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // forgotpasswordeph (6:684)
                                  margin: EdgeInsets.fromLTRB(303.93*fem, 0*fem, 0*fem, 26.47*fem),
                                  child: Text(
                                    'Forgot password?',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14.1361694336*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.5*ffem/fem,
                                      decoration: TextDecoration.underline,
                                      color: Color(0xff1e2772),
                                      decorationColor: Color(0xff1e2772),
                                    ),
                                  ),
                                ),
                                Container(
                                  // group5mPX (6:685)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.79*fem, 39.38*fem),
                                  width: 429.13*fem,
                                  height: 50.49*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xfffd7401),
                                    borderRadius: BorderRadius.circular(8.0778102875*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x4cfd7401),
                                        offset: Offset(0*fem, 12.1167154312*fem),
                                        blurRadius: 12.1167154312*fem,
                                      ),
                                    ],
                                  ),
                                  child: Center(
                                    child: Text(
                                      'Login now',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 16.155620575*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // group6cuw (6:691)
                                  margin: EdgeInsets.fromLTRB(0.72*fem, 0*fem, 0*fem, 38.58*fem),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // line1hwP (6:692)
                                        margin: EdgeInsets.fromLTRB(0*fem, 1.22*fem, 19.69*fem, 0*fem),
                                        width: 184.28*fem,
                                        height: 1.01*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffc2c2c2),
                                        ),
                                      ),
                                      Container(
                                        // orERX (6:694)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 20.39*fem, 0*fem),
                                        child: Text(
                                          'OR',
                                          style: SafeGoogleFont (
                                            'Poppins',
                                            fontSize: 14.1361694336*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.5*ffem/fem,
                                            color: Color(0xffc2c2c2),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // line2waq (6:693)
                                        margin: EdgeInsets.fromLTRB(0*fem, 1.22*fem, 0*fem, 0*fem),
                                        width: 184.28*fem,
                                        height: 1.01*fem,
                                        decoration: BoxDecoration (
                                          color: Color(0xffc2c2c2),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // group7Gt1 (6:688)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.79*fem, 0*fem),
                                  width: 429.13*fem,
                                  height: 50.49*fem,
                                  decoration: BoxDecoration (
                                    border: Border.all(color: Color(0xfffd7401)),
                                    borderRadius: BorderRadius.circular(8.0778102875*fem),
                                  ),
                                  child: Center(
                                    child: Text(
                                      'Signup now',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 16.155620575*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xfffd7401),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupn4hkkHP (ViQWeitSvEK5p6PQZhN4HK)
                            padding: EdgeInsets.fromLTRB(274.64*fem, 229.46*fem, 266.11*fem, 245.34*fem),
                            width: 1086*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xfff1f3f6),
                            ),
                            child: Container(
                              // mobileloginpana1sN1 (6:695)
                              width: double.infinity,
                              height: double.infinity,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // freepikbackgroundcompleteinjec (6:696)
                                    left: 0*fem,
                                    top: 0*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 545.25*fem,
                                        height: 469.97*fem,
                                        child: Image.asset(
                                          'assets/cover/images/freepik-background-complete-inject-60.png',
                                          width: 545.25*fem,
                                          height: 469.97*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // freepikfloorinject60T5K (6:730)
                                    left: 68.9075927734*fem,
                                    top: 534.5374755859*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 395.87*fem,
                                        height: 0.66*fem,
                                        child: Image.asset(
                                          'assets/cover/images/freepik-floor-inject-60.png',
                                          width: 395.87*fem,
                                          height: 0.66*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // freepikplantinject609iq (6:732)
                                    left: 354.9315185547*fem,
                                    top: 242.6538696289*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 106.04*fem,
                                        height: 182.49*fem,
                                        child: Image.asset(
                                          'assets/cover/images/freepik-plant-inject-60-cj3.png',
                                          width: 106.04*fem,
                                          height: 182.49*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // freepikpadlockinject60qLm (6:739)
                                    left: 348.7377929688*fem,
                                    top: 5.9596862793*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 106.31*fem,
                                        height: 127.16*fem,
                                        child: Image.asset(
                                          'assets/cover/images/freepik-padlock-inject-60.png',
                                          width: 106.31*fem,
                                          height: 127.16*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // freepikdeviceinject609MT (6:745)
                                    left: 201.2331542969*fem,
                                    top: 62.3849487305*fem,
                                    child: Container(
                                      width: 184.37*fem,
                                      height: 375.73*fem,
                                      decoration: BoxDecoration (
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/cover/images/vector-KBF.png',
                                          ),
                                        ),
                                      ),
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            // vectorV3w (6:747)
                                            left: 8.4869384766*fem,
                                            top: 11.1420288086*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 167.39*fem,
                                                height: 351.33*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-Rih.png',
                                                  width: 167.39*fem,
                                                  height: 351.33*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorP9K (6:748)
                                            left: 43.0620117188*fem,
                                            top: 290.9442749023*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 98.27*fem,
                                                height: 29.9*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-tqf.png',
                                                  width: 98.27*fem,
                                                  height: 29.9*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // singupJXB (6:749)
                                            left: 70.5024414062*fem,
                                            top: 298.2970581055*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 43*fem,
                                                height: 13*fem,
                                                child: Text(
                                                  'SING UP',
                                                  style: SafeGoogleFont (
                                                    'Inter',
                                                    fontSize: 10.3779125214*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.2125*ffem/fem,
                                                    color: Color(0xffe8e8e3),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorCcZ (6:750)
                                            left: 30.8389892578*fem,
                                            top: 103.1292724609*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 32.85*fem,
                                                height: 6.17*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-Z7o.png',
                                                  width: 32.85*fem,
                                                  height: 6.17*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorH8D (6:751)
                                            left: 30.8389892578*fem,
                                            top: 103.1292724609*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 32.85*fem,
                                                height: 6.17*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-QdX.png',
                                                  width: 32.85*fem,
                                                  height: 6.17*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorD1s (6:752)
                                            left: 30.4212646484*fem,
                                            top: 117.776550293*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 131.79*fem,
                                                height: 22.49*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-qCD.png',
                                                  width: 131.79*fem,
                                                  height: 22.49*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vector8uX (6:753)
                                            left: 40.7263183594*fem,
                                            top: 124.9749755859*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 60.04*fem,
                                                height: 5.63*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-kLq.png',
                                                  width: 60.04*fem,
                                                  height: 5.63*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorSvD (6:754)
                                            left: 40.7263183594*fem,
                                            top: 124.9749755859*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 60.04*fem,
                                                height: 5.63*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-Yc1.png',
                                                  width: 60.04*fem,
                                                  height: 5.63*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectormxV (6:755)
                                            left: 30.6148681641*fem,
                                            top: 158.0849609375*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 32.85*fem,
                                                height: 6.17*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-yLD.png',
                                                  width: 32.85*fem,
                                                  height: 6.17*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vector5TP (6:756)
                                            left: 30.6148681641*fem,
                                            top: 158.0849609375*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 32.85*fem,
                                                height: 6.17*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-Zgu.png',
                                                  width: 32.85*fem,
                                                  height: 6.17*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectoroeH (6:757)
                                            left: 30.1257324219*fem,
                                            top: 172.8743286133*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 131.8*fem,
                                                height: 22.43*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-RUu.png',
                                                  width: 131.8*fem,
                                                  height: 22.43*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorJL9 (6:758)
                                            left: 30.3677978516*fem,
                                            top: 215.4271240234*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 32.85*fem,
                                                height: 6.17*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-4gh.png',
                                                  width: 32.85*fem,
                                                  height: 6.17*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorq5B (6:759)
                                            left: 30.3677978516*fem,
                                            top: 215.4271240234*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 32.85*fem,
                                                height: 6.17*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-uPF.png',
                                                  width: 32.85*fem,
                                                  height: 6.17*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorXyb (6:760)
                                            left: 29.9854736328*fem,
                                            top: 230.0269165039*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 131.79*fem,
                                                height: 22.53*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-F3f.png',
                                                  width: 131.79*fem,
                                                  height: 22.53*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectoreHX (6:761)
                                            left: 39.4201660156*fem,
                                            top: 181.2510375977*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 60.06*fem,
                                                height: 5.9*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-Hyj.png',
                                                  width: 60.06*fem,
                                                  height: 5.9*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorNjK (6:762)
                                            left: 39.4201660156*fem,
                                            top: 181.2510375977*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 60.06*fem,
                                                height: 5.9*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-ony.png',
                                                  width: 60.06*fem,
                                                  height: 5.9*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorH5b (6:763)
                                            left: 39.6229248047*fem,
                                            top: 239.3045043945*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 5.25*fem,
                                                height: 5.26*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-4LR.png',
                                                  width: 5.25*fem,
                                                  height: 5.26*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorQR7 (6:764)
                                            left: 47.7524414062*fem,
                                            top: 239.3521728516*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 5.26*fem,
                                                height: 5.62*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-zRo.png',
                                                  width: 5.26*fem,
                                                  height: 5.62*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vector6Yq (6:765)
                                            left: 55.8961181641*fem,
                                            top: 239.3810424805*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 5.25*fem,
                                                height: 5.26*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-d8m.png',
                                                  width: 5.25*fem,
                                                  height: 5.26*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorcn5 (6:766)
                                            left: 64.0260009766*fem,
                                            top: 239.4194335938*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 5.25*fem,
                                                height: 5.26*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-tAV.png',
                                                  width: 5.25*fem,
                                                  height: 5.26*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vector8Ed (6:767)
                                            left: 72.1551513672*fem,
                                            top: 239.4576416016*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 5.25*fem,
                                                height: 5.26*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-mxV.png',
                                                  width: 5.25*fem,
                                                  height: 5.26*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorp7T (6:768)
                                            left: 80.2976074219*fem,
                                            top: 239.4968261719*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 5.25*fem,
                                                height: 5.26*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-pFj.png',
                                                  width: 5.25*fem,
                                                  height: 5.26*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorYJM (6:769)
                                            left: 88.4279785156*fem,
                                            top: 239.5308227539*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 5.26*fem,
                                                height: 5.62*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-owf.png',
                                                  width: 5.26*fem,
                                                  height: 5.62*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorGk9 (6:770)
                                            left: 96.5578613281*fem,
                                            top: 239.5735473633*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 5.25*fem,
                                                height: 5.26*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-XbP.png',
                                                  width: 5.25*fem,
                                                  height: 5.26*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorzRF (6:771)
                                            left: 104.6877441406*fem,
                                            top: 239.6108398438*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 5.25*fem,
                                                height: 5.26*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-dxD.png',
                                                  width: 5.25*fem,
                                                  height: 5.26*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // group6DP (6:772)
                                            left: 39.6229248047*fem,
                                            top: 239.3045043945*fem,
                                            child: Opacity(
                                              opacity: 0.2,
                                              child: Container(
                                                width: 70.32*fem,
                                                height: 5.85*fem,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // vectorzpZ (6:773)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.88*fem, 0.59*fem),
                                                      width: 5.25*fem,
                                                      height: 5.26*fem,
                                                      child: Image.asset(
                                                        'assets/cover/images/vector-rTb.png',
                                                        width: 5.25*fem,
                                                        height: 5.26*fem,
                                                      ),
                                                    ),
                                                    Container(
                                                      // vectorvTK (6:774)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.89*fem, 0.13*fem),
                                                      width: 5.26*fem,
                                                      height: 5.62*fem,
                                                      child: Image.asset(
                                                        'assets/cover/images/vector-3Yu.png',
                                                        width: 5.26*fem,
                                                        height: 5.62*fem,
                                                      ),
                                                    ),
                                                    Container(
                                                      // vectordcd (6:775)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.88*fem, 0.44*fem),
                                                      width: 5.25*fem,
                                                      height: 5.26*fem,
                                                      child: Image.asset(
                                                        'assets/cover/images/vector-fCD.png',
                                                        width: 5.25*fem,
                                                        height: 5.26*fem,
                                                      ),
                                                    ),
                                                    Container(
                                                      // vectorvLq (6:776)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.88*fem, 0.36*fem),
                                                      width: 5.25*fem,
                                                      height: 5.26*fem,
                                                      child: Image.asset(
                                                        'assets/cover/images/vector-NUh.png',
                                                        width: 5.25*fem,
                                                        height: 5.26*fem,
                                                      ),
                                                    ),
                                                    Container(
                                                      // vectorE6d (6:777)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.89*fem, 0.29*fem),
                                                      width: 5.25*fem,
                                                      height: 5.26*fem,
                                                      child: Image.asset(
                                                        'assets/cover/images/vector-puP.png',
                                                        width: 5.25*fem,
                                                        height: 5.26*fem,
                                                      ),
                                                    ),
                                                    Container(
                                                      // vectorxYR (6:778)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.88*fem, 0.21*fem),
                                                      width: 5.25*fem,
                                                      height: 5.26*fem,
                                                      child: Image.asset(
                                                        'assets/cover/images/vector-m7o.png',
                                                        width: 5.25*fem,
                                                        height: 5.26*fem,
                                                      ),
                                                    ),
                                                    Container(
                                                      // vector6ed (6:779)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0.23*fem, 2.87*fem, 0*fem),
                                                      width: 5.26*fem,
                                                      height: 5.62*fem,
                                                      child: Image.asset(
                                                        'assets/cover/images/vector.png',
                                                        width: 5.26*fem,
                                                        height: 5.62*fem,
                                                      ),
                                                    ),
                                                    Container(
                                                      // vectorcss (6:780)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.88*fem, 0.05*fem),
                                                      width: 5.25*fem,
                                                      height: 5.26*fem,
                                                      child: Image.asset(
                                                        'assets/cover/images/vector-LqP.png',
                                                        width: 5.25*fem,
                                                        height: 5.26*fem,
                                                      ),
                                                    ),
                                                    Container(
                                                      // vectorwv9 (6:781)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0.02*fem, 0*fem, 0*fem),
                                                      width: 5.25*fem,
                                                      height: 5.26*fem,
                                                      child: Image.asset(
                                                        'assets/cover/images/vector-WT3.png',
                                                        width: 5.25*fem,
                                                        height: 5.26*fem,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorgcq (6:782)
                                            left: 88.1896972656*fem,
                                            top: 48.7028198242*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 16.9*fem,
                                                height: 18.43*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-drq.png',
                                                  width: 16.9*fem,
                                                  height: 18.43*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorMiy (6:783)
                                            left: 88.1896972656*fem,
                                            top: 48.7028198242*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 16.9*fem,
                                                height: 18.43*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-Ddj.png',
                                                  width: 16.9*fem,
                                                  height: 18.43*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorU2u (6:784)
                                            left: 65.5882568359*fem,
                                            top: 71.8650512695*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 60.26*fem,
                                                height: 7.47*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-84Z.png',
                                                  width: 60.26*fem,
                                                  height: 7.47*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            // vectorabj (6:785)
                                            left: 65.5882568359*fem,
                                            top: 71.8650512695*fem,
                                            child: Align(
                                              child: SizedBox(
                                                width: 60.26*fem,
                                                height: 7.47*fem,
                                                child: Image.asset(
                                                  'assets/cover/images/vector-kMX.png',
                                                  width: 60.26*fem,
                                                  height: 7.47*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // freepikspeechbubbleinject60Jnd (6:786)
                                    left: 72.8323974609*fem,
                                    top: 171.8273925781*fem,
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(20.27*fem, 17.88*fem, 18.96*fem, 28.61*fem),
                                      width: 65.82*fem,
                                      height: 74.74*fem,
                                      decoration: BoxDecoration (
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/cover/images/vector-pfs.png',
                                          ),
                                        ),
                                      ),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // vectorPp5 (6:788)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.19*fem, 0*fem),
                                            width: 19.92*fem,
                                            height: 28.25*fem,
                                            child: Image.asset(
                                              'assets/cover/images/vector-Rv1.png',
                                              width: 19.92*fem,
                                              height: 28.25*fem,
                                            ),
                                          ),
                                          Container(
                                            // vectorG7B (6:789)
                                            margin: EdgeInsets.fromLTRB(0*fem, 9.13*fem, 0*fem, 0*fem),
                                            width: 5.49*fem,
                                            height: 16.13*fem,
                                            child: Image.asset(
                                              'assets/cover/images/vector-aX3.png',
                                              width: 5.49*fem,
                                              height: 16.13*fem,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // freepikcharacterinject60bQM (6:790)
                                    left: 105.6520996094*fem,
                                    top: 179.4146118164*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 182.76*fem,
                                        height: 355.3*fem,
                                        child: Image.asset(
                                          'assets/cover/images/freepik-character-inject-60.png',
                                          width: 182.76*fem,
                                          height: 355.3*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}