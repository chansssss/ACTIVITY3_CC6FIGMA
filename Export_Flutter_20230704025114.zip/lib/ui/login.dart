import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 1728;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // logineuF (6:1265)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogrouprugz8pR (ViQbSfjesXJ4jmneCQRuGZ)
              padding: EdgeInsets.fromLTRB(35*fem, 206*fem, 35*fem, 207*fem),
              width: 480*fem,
              height: 1000*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x19000000),
                    offset: Offset(0*fem, 12*fem),
                    blurRadius: 25*fem,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // logoMhB (6:1272)
                    margin: EdgeInsets.fromLTRB(96*fem, 0*fem, 96*fem, 23.46*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // rectangle45dB (6:1273)
                          margin: EdgeInsets.fromLTRB(0*fem, 4.15*fem, 5.54*fem, 0*fem),
                          width: 5.54*fem,
                          height: 55.39*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(16.6165885925*fem),
                            color: Color(0xfffd7401),
                          ),
                        ),
                        Container(
                          // rectangle5brR (6:1276)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.54*fem, 4.15*fem),
                          width: 5.54*fem,
                          height: 55.39*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(16.6165885925*fem),
                            color: Color(0xff1e2772),
                          ),
                        ),
                        Container(
                          // rectangle6WiV (6:1274)
                          margin: EdgeInsets.fromLTRB(0*fem, 4.15*fem, 5.54*fem, 0*fem),
                          width: 5.54*fem,
                          height: 55.39*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(16.6165885925*fem),
                            color: Color(0xfffd7401),
                          ),
                        ),
                        Container(
                          // rectangle7DN1 (6:1277)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.54*fem, 4.15*fem),
                          width: 5.54*fem,
                          height: 55.39*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(16.6165885925*fem),
                            color: Color(0xff1e2772),
                          ),
                        ),
                        Container(
                          // rectangle8W6D (6:1275)
                          margin: EdgeInsets.fromLTRB(0*fem, 4.15*fem, 5.54*fem, 0*fem),
                          width: 5.54*fem,
                          height: 55.39*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(16.6165885925*fem),
                            color: Color(0xfffd7401),
                          ),
                        ),
                        Container(
                          // networkzn5 (6:1278)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.43*fem),
                          width: 162.61*fem,
                          height: 30.03*fem,
                          child: Image.asset(
                            'assets/ui/images/network-3Jh.png',
                            width: 162.61*fem,
                            height: 30.03*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // loginintoyouraccountX1K (6:1279)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 45*fem),
                    child: Text(
                      'Login into your account',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.5*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // group2ozR (6:1287)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 23*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // emailaddress9YV (6:1281)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 10*fem),
                          child: Text(
                            'Email Address',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.5*ffem/fem,
                              color: Color(0xff555555),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupwrldEpq (ViQbrEtiBPQFecJUTPWrLD)
                          padding: EdgeInsets.fromLTRB(19*fem, 0*fem, 0*fem, 0*fem),
                          width: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xfff1f3f6),
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // alexemailcomvSm (6:1282)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 207*fem, 0*fem),
                                child: Text(
                                  'alex@email.com',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xff555555),
                                  ),
                                ),
                              ),
                              Container(
                                // autogroupoceybJ1 (ViQbvuRc55rUsjEk9roCey)
                                width: 50*fem,
                                height: 50*fem,
                                child: Image.asset(
                                  'assets/ui/images/auto-group-ocey.png',
                                  width: 50*fem,
                                  height: 50*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group3XSZ (6:1288)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 10*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // passwordSpR (6:1291)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 10*fem),
                          child: Text(
                            'Password',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.5*ffem/fem,
                              color: Color(0xff555555),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupb4shNi5 (ViQcAENjUWHhonUwrvB4SH)
                          padding: EdgeInsets.fromLTRB(19*fem, 0*fem, 0*fem, 0*fem),
                          width: double.infinity,
                          decoration: BoxDecoration (
                            color: Color(0xfff1f3f6),
                            borderRadius: BorderRadius.circular(8*fem),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // enteryourpasswordhkM (6:1292)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 178*fem, 0*fem),
                                child: Text(
                                  'Enter your password',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xff555555),
                                  ),
                                ),
                              ),
                              Container(
                                // autogroupad4hde1 (ViQcF4a1w7yJDjJsQUaD4H)
                                width: 50*fem,
                                height: 50*fem,
                                child: Image.asset(
                                  'assets/ui/images/auto-group-ad4h.png',
                                  width: 50*fem,
                                  height: 50*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // forgotpassword8Ks (6:1299)
                    margin: EdgeInsets.fromLTRB(286*fem, 0*fem, 0*fem, 33*fem),
                    child: Text(
                      'Forgot Password?',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.5*ffem/fem,
                        decoration: TextDecoration.underline,
                        color: Color(0xff1e2772),
                        decorationColor: Color(0xff1e2772),
                      ),
                    ),
                  ),
                  Container(
                    // group4qzy (6:1305)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 30*fem),
                    width: double.infinity,
                    height: 50*fem,
                    decoration: BoxDecoration (
                      color: Color(0xfffd7401),
                      borderRadius: BorderRadius.circular(8*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x4cfd7401),
                          offset: Offset(0*fem, 8*fem),
                          blurRadius: 6*fem,
                        ),
                      ],
                    ),
                    child: Center(
                      child: Text(
                        'Login Now',
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 16*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.5*ffem/fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // group55uK (6:1310)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 23*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // line1pM7 (6:1306)
                          margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 0*fem, 0*fem),
                          width: 175*fem,
                          height: 1*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffc2c2c2),
                          ),
                        ),
                        SizedBox(
                          width: 20*fem,
                        ),
                        Text(
                          // orwRj (6:1307)
                          'OR',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            color: Color(0xffc2c2c2),
                          ),
                        ),
                        SizedBox(
                          width: 20*fem,
                        ),
                        Container(
                          // line24WM (6:1309)
                          margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 0*fem, 0*fem),
                          width: 175*fem,
                          height: 1*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffc2c2c2),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // group6ydK (6:1311)
                    width: double.infinity,
                    height: 50*fem,
                    decoration: BoxDecoration (
                      border: Border.all(color: Color(0xfffd7401)),
                      borderRadius: BorderRadius.circular(8*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x4cfd7401),
                          offset: Offset(0*fem, 8*fem),
                          blurRadius: 6*fem,
                        ),
                      ],
                    ),
                    child: Center(
                      child: Text(
                        'Signup Now',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 16*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.5*ffem/fem,
                          color: Color(0xfffd7401),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupoffsF53 (ViQcWJdcs6ZDoHJ5M3oFFs)
              padding: EdgeInsets.fromLTRB(358.16*fem, 227.04*fem, 349.85*fem, 242.91*fem),
              width: 1248*fem,
              height: 1000*fem,
              decoration: BoxDecoration (
                color: Color(0xfff1f3f6),
              ),
              child: Container(
                // loginillustratory13 (6:1314)
                width: double.infinity,
                height: double.infinity,
                child: Stack(
                  children: [
                    Positioned(
                      // freepikbackgroundcompleteinjec (6:1315)
                      left: 0*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 539.99*fem,
                          height: 465.44*fem,
                          child: Image.asset(
                            'assets/ui/images/freepik-background-complete-inject-60-gnD.png',
                            width: 539.99*fem,
                            height: 465.44*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // freepikfloorinject60uYu (6:1349)
                      left: 68.2434082031*fem,
                      top: 529.3885498047*fem,
                      child: Align(
                        child: SizedBox(
                          width: 392.05*fem,
                          height: 0.66*fem,
                          child: Image.asset(
                            'assets/ui/images/freepik-floor-inject-60-ETB.png',
                            width: 392.05*fem,
                            height: 0.66*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // freepikplantinject60QVf (6:1351)
                      left: 351.5122070312*fem,
                      top: 240.3164672852*fem,
                      child: Align(
                        child: SizedBox(
                          width: 105.02*fem,
                          height: 180.73*fem,
                          child: Image.asset(
                            'assets/ui/images/freepik-plant-inject-60.png',
                            width: 105.02*fem,
                            height: 180.73*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // freepikpadlockinject60UkR (6:1358)
                      left: 345.3784179688*fem,
                      top: 5.9022216797*fem,
                      child: Align(
                        child: SizedBox(
                          width: 105.29*fem,
                          height: 125.93*fem,
                          child: Image.asset(
                            'assets/ui/images/freepik-padlock-inject-60-zUq.png',
                            width: 105.29*fem,
                            height: 125.93*fem,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // freepikdeviceinject60A7T (6:1364)
                      left: 199.2946777344*fem,
                      top: 61.783996582*fem,
                      child: Container(
                        width: 182.6*fem,
                        height: 372.11*fem,
                        decoration: BoxDecoration (
                          image: DecorationImage (
                            fit: BoxFit.cover,
                            image: AssetImage (
                              'assets/ui/images/vector-PR3.png',
                            ),
                          ),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              // vectorzMP (6:1366)
                              left: 8.4057617188*fem,
                              top: 11.0347290039*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 165.77*fem,
                                  height: 347.94*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-bZb.png',
                                    width: 165.77*fem,
                                    height: 347.94*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectoruUM (6:1367)
                              left: 42.6474609375*fem,
                              top: 288.141784668*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 97.32*fem,
                                  height: 29.62*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-oL5.png',
                                    width: 97.32*fem,
                                    height: 29.62*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // singupc7s (6:1368)
                              left: 69.8237304688*fem,
                              top: 295.4236450195*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 42*fem,
                                  height: 13*fem,
                                  child: Text(
                                    'SING UP',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 10.2779455185*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xffe8e8e3),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorFgd (6:1369)
                              left: 30.5422363281*fem,
                              top: 102.135925293*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 32.54*fem,
                                  height: 6.11*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-51T.png',
                                    width: 32.54*fem,
                                    height: 6.11*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorB4V (6:1370)
                              left: 30.5422363281*fem,
                              top: 102.135925293*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 32.54*fem,
                                  height: 6.11*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-Ykh.png',
                                    width: 32.54*fem,
                                    height: 6.11*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorVqs (6:1371)
                              left: 30.1286621094*fem,
                              top: 116.6420898438*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 130.52*fem,
                                  height: 22.27*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-ik9.png',
                                    width: 130.52*fem,
                                    height: 22.27*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorRUd (6:1372)
                              left: 40.3344726562*fem,
                              top: 123.7711791992*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 59.46*fem,
                                  height: 5.57*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-G2M.png',
                                    width: 59.46*fem,
                                    height: 5.57*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorwC5 (6:1373)
                              left: 40.3344726562*fem,
                              top: 123.7711791992*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 59.46*fem,
                                  height: 5.57*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-X3w.png',
                                    width: 59.46*fem,
                                    height: 5.57*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorTw7 (6:1374)
                              left: 30.3205566406*fem,
                              top: 156.5621948242*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 32.54*fem,
                                  height: 6.11*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-1m3.png',
                                    width: 32.54*fem,
                                    height: 6.11*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vector4vu (6:1375)
                              left: 30.3205566406*fem,
                              top: 156.5621948242*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 32.54*fem,
                                  height: 6.11*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-hpd.png',
                                    width: 32.54*fem,
                                    height: 6.11*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorZsf (6:1376)
                              left: 29.8359375*fem,
                              top: 171.2091674805*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 130.53*fem,
                                  height: 22.22*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-igH.png',
                                    width: 130.53*fem,
                                    height: 22.22*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vector5LD (6:1377)
                              left: 30.0754394531*fem,
                              top: 213.3519897461*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 32.54*fem,
                                  height: 6.11*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-jE1.png',
                                    width: 32.54*fem,
                                    height: 6.11*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vector1Ds (6:1378)
                              left: 30.0754394531*fem,
                              top: 213.3519897461*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 32.54*fem,
                                  height: 6.11*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-AhP.png',
                                    width: 32.54*fem,
                                    height: 6.11*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorHSH (6:1379)
                              left: 29.6970214844*fem,
                              top: 227.8110961914*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 130.52*fem,
                                  height: 22.32*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-5FF.png',
                                    width: 130.52*fem,
                                    height: 22.32*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorQ17 (6:1380)
                              left: 39.0405273438*fem,
                              top: 179.5051879883*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 59.48*fem,
                                  height: 5.84*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-EYy.png',
                                    width: 59.48*fem,
                                    height: 5.84*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorXbX (6:1381)
                              left: 39.0405273438*fem,
                              top: 179.5051879883*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 59.48*fem,
                                  height: 5.84*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-HPX.png',
                                    width: 59.48*fem,
                                    height: 5.84*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vector2HP (6:1382)
                              left: 39.2416992188*fem,
                              top: 236.9993896484*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 5.2*fem,
                                  height: 5.21*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-V69.png',
                                    width: 5.2*fem,
                                    height: 5.21*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorXV3 (6:1383)
                              left: 47.2927246094*fem,
                              top: 237.0465698242*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 5.21*fem,
                                  height: 5.57*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-CCR.png',
                                    width: 5.21*fem,
                                    height: 5.57*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorSru (6:1384)
                              left: 55.3576660156*fem,
                              top: 237.0752563477*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 5.2*fem,
                                  height: 5.21*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-g8R.png',
                                    width: 5.2*fem,
                                    height: 5.21*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorkMo (6:1385)
                              left: 63.4094238281*fem,
                              top: 237.1132202148*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 5.2*fem,
                                  height: 5.21*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-4yX.png',
                                    width: 5.2*fem,
                                    height: 5.21*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorGb3 (6:1386)
                              left: 71.4602050781*fem,
                              top: 237.1510620117*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 5.2*fem,
                                  height: 5.21*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-YkZ.png',
                                    width: 5.2*fem,
                                    height: 5.21*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorBCD (6:1387)
                              left: 79.5244140625*fem,
                              top: 237.1898803711*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 5.2*fem,
                                  height: 5.21*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-DUd.png',
                                    width: 5.2*fem,
                                    height: 5.21*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectoruP7 (6:1388)
                              left: 87.5764160156*fem,
                              top: 237.2235107422*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 5.21*fem,
                                  height: 5.57*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-zY1.png',
                                    width: 5.21*fem,
                                    height: 5.57*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorR6Z (6:1389)
                              left: 95.6279296875*fem,
                              top: 237.2658081055*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 5.2*fem,
                                  height: 5.21*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-yEh.png',
                                    width: 5.2*fem,
                                    height: 5.21*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorirM (6:1390)
                              left: 103.6796875*fem,
                              top: 237.3027954102*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 5.2*fem,
                                  height: 5.21*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-n8h.png',
                                    width: 5.2*fem,
                                    height: 5.21*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // groupTJ9 (6:1391)
                              left: 39.2416992188*fem,
                              top: 236.9993896484*fem,
                              child: Opacity(
                                opacity: 0.2,
                                child: Container(
                                  width: 69.64*fem,
                                  height: 5.79*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // vectorACZ (6:1392)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.85*fem, 0.59*fem),
                                        width: 5.2*fem,
                                        height: 5.21*fem,
                                        child: Image.asset(
                                          'assets/ui/images/vector-stM.png',
                                          width: 5.2*fem,
                                          height: 5.21*fem,
                                        ),
                                      ),
                                      Container(
                                        // vectorGmP (6:1393)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.86*fem, 0.13*fem),
                                        width: 5.21*fem,
                                        height: 5.57*fem,
                                        child: Image.asset(
                                          'assets/ui/images/vector-J9F.png',
                                          width: 5.21*fem,
                                          height: 5.57*fem,
                                        ),
                                      ),
                                      Container(
                                        // vectora1P (6:1394)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.85*fem, 0.43*fem),
                                        width: 5.2*fem,
                                        height: 5.21*fem,
                                        child: Image.asset(
                                          'assets/ui/images/vector-rrM.png',
                                          width: 5.2*fem,
                                          height: 5.21*fem,
                                        ),
                                      ),
                                      Container(
                                        // vectorJi5 (6:1395)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.85*fem, 0.36*fem),
                                        width: 5.2*fem,
                                        height: 5.21*fem,
                                        child: Image.asset(
                                          'assets/ui/images/vector-pW5.png',
                                          width: 5.2*fem,
                                          height: 5.21*fem,
                                        ),
                                      ),
                                      Container(
                                        // vectorqi1 (6:1396)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.86*fem, 0.28*fem),
                                        width: 5.2*fem,
                                        height: 5.21*fem,
                                        child: Image.asset(
                                          'assets/ui/images/vector-Tq3.png',
                                          width: 5.2*fem,
                                          height: 5.21*fem,
                                        ),
                                      ),
                                      Container(
                                        // vectorNT3 (6:1397)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.85*fem, 0.21*fem),
                                        width: 5.2*fem,
                                        height: 5.21*fem,
                                        child: Image.asset(
                                          'assets/ui/images/vector-Bv1.png',
                                          width: 5.2*fem,
                                          height: 5.21*fem,
                                        ),
                                      ),
                                      Container(
                                        // vectorhkD (6:1398)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0.22*fem, 2.84*fem, 0*fem),
                                        width: 5.21*fem,
                                        height: 5.57*fem,
                                        child: Image.asset(
                                          'assets/ui/images/vector-Aqo.png',
                                          width: 5.21*fem,
                                          height: 5.57*fem,
                                        ),
                                      ),
                                      Container(
                                        // vectora3K (6:1399)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2.85*fem, 0.05*fem),
                                        width: 5.2*fem,
                                        height: 5.21*fem,
                                        child: Image.asset(
                                          'assets/ui/images/vector-tXK.png',
                                          width: 5.2*fem,
                                          height: 5.21*fem,
                                        ),
                                      ),
                                      Container(
                                        // vectorubP (6:1400)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0.02*fem, 0*fem, 0*fem),
                                        width: 5.2*fem,
                                        height: 5.21*fem,
                                        child: Image.asset(
                                          'assets/ui/images/vector-X8V.png',
                                          width: 5.2*fem,
                                          height: 5.21*fem,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectorF9T (6:1401)
                              left: 87.3405761719*fem,
                              top: 48.2337036133*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 16.74*fem,
                                  height: 18.25*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-Fcd.png',
                                    width: 16.74*fem,
                                    height: 18.25*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vectoryLM (6:1402)
                              left: 87.3405761719*fem,
                              top: 48.2337036133*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 16.74*fem,
                                  height: 18.25*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-ao3.png',
                                    width: 16.74*fem,
                                    height: 18.25*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vector5uB (6:1403)
                              left: 64.9562988281*fem,
                              top: 71.1727905273*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 59.68*fem,
                                  height: 7.4*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-9y3.png',
                                    width: 59.68*fem,
                                    height: 7.4*fem,
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              // vector23j (6:1404)
                              left: 64.9562988281*fem,
                              top: 71.1727905273*fem,
                              child: Align(
                                child: SizedBox(
                                  width: 59.68*fem,
                                  height: 7.4*fem,
                                  child: Image.asset(
                                    'assets/ui/images/vector-NwB.png',
                                    width: 59.68*fem,
                                    height: 7.4*fem,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // freepikspeechbubbleinject6086m (6:1405)
                      left: 72.1301269531*fem,
                      top: 170.1722412109*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(20.07*fem, 17.71*fem, 18.77*fem, 28.34*fem),
                        width: 65.18*fem,
                        height: 74.02*fem,
                        decoration: BoxDecoration (
                          image: DecorationImage (
                            fit: BoxFit.cover,
                            image: AssetImage (
                              'assets/ui/images/vector-HNq.png',
                            ),
                          ),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // vectorMkD (6:1407)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.18*fem, 0*fem),
                              width: 19.72*fem,
                              height: 27.97*fem,
                              child: Image.asset(
                                'assets/ui/images/vector-Xa1.png',
                                width: 19.72*fem,
                                height: 27.97*fem,
                              ),
                            ),
                            Container(
                              // vectorrws (6:1408)
                              margin: EdgeInsets.fromLTRB(0*fem, 9.04*fem, 0*fem, 0*fem),
                              width: 5.44*fem,
                              height: 15.98*fem,
                              child: Image.asset(
                                'assets/ui/images/vector-iTK.png',
                                width: 5.44*fem,
                                height: 15.98*fem,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // freepikcharacterinject60o6R (6:1409)
                      left: 104.6340332031*fem,
                      top: 177.6864013672*fem,
                      child: Align(
                        child: SizedBox(
                          width: 181*fem,
                          height: 351.88*fem,
                          child: Image.asset(
                            'assets/ui/images/freepik-character-inject-60-KKo.png',
                            width: 181*fem,
                            height: 351.88*fem,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}